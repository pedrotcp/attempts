from .main import init, printt
import builtins

builtins.printt = printt
